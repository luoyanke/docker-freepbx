<?php
/**
 * FreePBX Notifications
 *
 * This has been replaced with a BMO interface.
 */

if (!class_exists('Freepbx_conf')) {
	include 'BMO/Freepbx_conf.class.php';
}
