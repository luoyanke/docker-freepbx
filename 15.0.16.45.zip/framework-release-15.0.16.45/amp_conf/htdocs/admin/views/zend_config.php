<div style='margin-left:20px;margin-right:20px'>
	<h2><?php echo _("Zend Mis-Configuration")?></h2>
	<p><?php echo _("You are attempting to load licensed modules without a proper Zend Guard Configuration. Please ensure you have Zend Guard installed on your system and have downloaded a license via the System Administration module.")?></p>
</div>
