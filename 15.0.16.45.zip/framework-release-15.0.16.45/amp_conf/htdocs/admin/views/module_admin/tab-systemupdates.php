<?php
// vim: :set filetype=php tabstop=4 shiftwidth=4 autoindent smartindent:
?>
<div role="tabpanel" class="tab-pane" id="systemupdatestab">
  <div class='container-fluid' id='systext'>
    <?php echo $sysupdatepage; ?>
  </div>
</div>
