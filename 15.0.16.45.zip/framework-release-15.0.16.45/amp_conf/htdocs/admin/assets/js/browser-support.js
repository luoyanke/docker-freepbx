//nothing to check for cross browser quirks at this time
