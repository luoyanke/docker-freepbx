<?php

include __DIR__.'/../ajax.php';
